/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package practica6calzadajonathan;

/**
 *
 * @author edaII05alu09
 */
public class Practica6CalzadaJonathan {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int V;
        // TODO code application logic here
        V = 5;
        
        
        Graph1 graph = new Graph1 (V);
        graph.addEdge(0,1);
        graph.addEdge(0,4);
        graph.addEdge(1,2);
        graph.addEdge(1,3);
        graph.addEdge(1,4);
        graph.addEdge(2,3);              
        graph.addEdge(3,4);
        graph.printGraph (graph);
    }
    
}
