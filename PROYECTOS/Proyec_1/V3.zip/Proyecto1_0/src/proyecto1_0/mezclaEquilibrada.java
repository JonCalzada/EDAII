package proyecto1_0;
import java.io.*;

public class mezclaEquilibrada {
    
}
