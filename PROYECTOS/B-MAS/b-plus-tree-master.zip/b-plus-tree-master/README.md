b-plus-tree
===========

A Java implementation of B+ tree for key-value store.

More things need to be considered:

1. Variable-length keys
2. Search unidirectionally
3. Allow duplicated keys
4. Concurrency
